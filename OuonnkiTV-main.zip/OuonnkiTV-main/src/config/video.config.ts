export const PaginationConfig = {
  singlePageSize: 16,
}
